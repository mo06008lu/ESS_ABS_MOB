jQuery.sap.declare("ess_abs_mob.util.Formatter");

jQuery.sap.require("sap.ui.core.format.DateFormat");

ess_abs_mob.util.Formatter = {
	
	date : function (value) {
		if (value) {
			var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({pattern: "dd-MM-yyyy"}); 
//			return oDateFormat.format(new Date(value));
		} else {
//			return 'NULL';
		}
		return '30.11.1986';
	}
};