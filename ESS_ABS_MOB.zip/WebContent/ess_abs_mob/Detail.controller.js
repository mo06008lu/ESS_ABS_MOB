jQuery.sap.require("ess_abs_mob.util.Formatter");
jQuery.sap.require("sap.m.MessageBox"); 
jQuery.sap.require("sap.m.MessageToast"); 
sap.ui.controller("ess_abs_mob.ess_abs_mob.Detail", {
	
	
	/**
	* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
	* (NOT before the first rendering! onInit() is used for that one!).
	* @memberOf ess_abs_mob.app
	*/
	onBeforeRendering: function(e) {
//			alert("hi");
	},

	/**
	* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
	* This hook is the same one that SAPUI5 controls get after being rendered.
	* @memberOf ess_abs_mob.app
	*/
	onAfterRendering: function(e) {
//			alert("hi");
	},
	
	changeRanges: function(e){
//		alert("hi");
	},	
	
	onBeforeShow: function(){
//		alert("hi");
	},

	onInit: function(e){
		var oCalendar = this.getView().byId('calendar');
		var data = sap.ui.getCore().getModel().getData();
		var dates = data.data.abscences;
		
		var aSelected;
		var oType = {};
		for( var i = 0; i < dates.length; i++ ){
			oCalendar.toggleDatesRangeSelection( dates[i].start , dates[i].end , true );
			aSelected = oCalendar.getSelectedDates();
			switch(dates[i].type){
				case "01": oType  = sap.me.CalendarEventType.Type01; break;
				case "02": oType  = sap.me.CalendarEventType.Type04; break;
				case "03": oType  = sap.me.CalendarEventType.Type06; break;
				default: oType  = sap.me.CalendarEventType.Type07; break;
				oCalendar.toggleDatesType( aSelected, oType, true);		
				oCalendar.unselectAllDates();		
			}
		}	
	},

	handleApprove:function (evt) { 
		// show confirmation dialog 
		 var bundle = this.getView().getModel("res").getResourceBundle(); 
		 sap.m.MessageBox.confirm( 
		 bundle.getText("ApproveDialogMsg"), 
		 function (oAction) { 
			 					if (sap.m.MessageBox.Action.OK === oAction) { 
		 // notify user 
			 						var successMsg = bundle.getText("ApproveDialogSuccessMsg"); 
			 						sap.m.MessageToast.show(successMsg); 
			 					} 
		 }, 
		 
		 bundle.getText("ApproveDialogTitle") 
		 ); 
	 },
	 
	 onPress: function(evt){
		    jQuery.sap.require("sap.m.MessageToast");
		    if (evt.getSource().getPressed()) {
		      sap.m.MessageToast.show(evt.getSource().getId() + " Pressed");
		    } else {
		      sap.m.MessageToast.show(evt.getSource().getId() + " Unpressed");
		    };
	 },
	 
	handleNavButtonPress : function (evt) {
			this.nav.back("Master");
	},

	
	


});